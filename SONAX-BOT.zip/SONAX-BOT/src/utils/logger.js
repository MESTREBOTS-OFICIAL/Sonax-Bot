const { version } = require("../../package.json");

exports.sayLog = (message) => {
  console.log("\x1b[36m[SONAX BOT FALANDO]\x1b[0m", message);
};

exports.inputLog = (message) => {
  console.log("\x1b[30m[SONAX BOT  ENTRADA]\x1b[0m", message);
};

exports.infoLog = (message) => {
  console.log("\x1b[34m[SONAX BOT INFORMAÇÕES]\x1b[0m", message);
};

exports.successLog = (message) => {
  console.log("\x1b[32m[SONAX BOT SUCCESSO]\x1b[0m", message);
};

exports.errorLog = (message) => {
  console.log("\x1b[31m[SONAX BOT ERRO]\x1b[0m", message);
};

exports.warningLog = (message) => {
  console.log("\x1b[33m[SONAX BOT AVISO]\x1b[0m", message);
};

exports.bannerLog = () => {
  console.log(`\x1b[36mBOT FEITO POR MIN KAUA NOME SONAX BOT\x1b[0m`);
  console.log(`\x1b[36mYT: MESTREBOTS-OFICIAL`);
  console.log(`\x1b[36mInstagram: KAUANUNUS2008\x1b[0m`);
};
