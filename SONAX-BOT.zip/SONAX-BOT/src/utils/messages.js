const { BOT_NAME, PREFIX } = require("../config");

exports.waitMessage = "⏳ Carregando dados... Por favor, aguarde! 💖";

exports.menuMessage = () => {
  const date = new Date();

  return `
╭━━━🎉 Bem-vindo ao ${BOT_NAME}! 🎉━━━╮
┃
┃ 🗓️ Data: ${date.toLocaleDateString("pt-br")}
┃ ⏰ Hora: ${date.toLocaleTimeString("pt-br")}
┃ ⚙️ Prefixo: ${PREFIX}
┃ 💬 Aproveite todos os comandos disponíveis!
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯

💖 *〘 DONO 〙* 💖
╭━━━━━━━━━━━━━━━━━━━╮
┃ 👑 ${PREFIX}off - Desligar o bot
┃ 👑 ${PREFIX}on - Ligar o bot
┃
╰━━━━━━━━━━━━━━━━━━━╯

🌟 *〘 ADMINS 〙* 🌟
╭━━━━━━━━━━━━━━━━━━━╮
┃ 🚫 ${PREFIX}anti-link (1/0) - Ativar/Desativar anti-links
┃ 🤖 ${PREFIX}auto-responder (1/0) - Respostas automáticas
┃ 🔨 ${PREFIX}ban - Banir membro
┃ 🔎 ${PREFIX}hidetag - Esconder tags
┃ 📨 ${PREFIX}welcome (1/0) - Mensagem de boas-vindas
┃
╰━━━━━━━━━━━━━━━━━━━╯

🚀 *〘 MENU PRINCIPAL 〙* 🚀
╭━━━━━━━━━━━━━━━━━━━╮
┃ 🖌️ ${PREFIX}attp - Texto animado
┃ 🗺️ ${PREFIX}cep - Consultar CEP
┃ 🤖 ${PREFIX}gpt-4 - Inteligência Artificial
┃ 📷 ${PREFIX}image - Gerar imagem
┃ 📶 ${PREFIX}ping - Testar latência
┃ 🎧 ${PREFIX}play-audio - Reproduzir áudio
┃ 📹 ${PREFIX}play-video - Reproduzir vídeo
┃ 🖼️ ${PREFIX}sticker - Criar figurinha
┃ 🖼️ ${PREFIX}to-image - Converter figurinha em imagem
┃
╰━━━━━━━━━━━━━━━━━━━╯

💌 *〘 MENSAGEM  〙* 💌
╭━━━━━━━━━━━━━━━━━━━╮
┃ 💖 Obrigado por usar o ${BOT_NAME}!
┃ ✨ Espero que aproveite ao máximo! Se precisar de ajuda, digite ${PREFIX}help.
┃ 💬 Mantenha o chat divertido e respeitoso!
╰━━━━━━━━━━━━━━━━━━━╯
  `;
};
