const { PREFIX } = require("../../config");

module.exports = {
  name: "hide-tag",
  description: "Este comando marcará todos do grupo",
  commands: ["hide-tag", "to-tag"],
  usage: `${PREFIX}hidetag <motivo>`,
  handle: async ({ fullArgs, sendText, socket, remoteJid, sendReact }) => {
    try {
      // Verifica se há argumentos
      if (!fullArgs) {
        await sendText("❌ Por favor, insira um motivo para usar este comando.");
        return;
      }

      // Garante que está sendo executado em um grupo
      const metadata = await socket.groupMetadata(remoteJid);
      if (!metadata) {
        await sendText("❌ Este comando só pode ser usado em grupos.");
        return;
      }

      const { participants } = metadata;
      const mentions = participants.map(({ id }) => id);

      await sendReact("📢"); // Reage com emoji
      await sendText(`📢 Marcando todos!\n\nMotivo: ${fullArgs}`, mentions);
    } catch (error) {
      console.error("Erro ao executar o comando:", error);
      await sendText("❌ Ocorreu um erro ao tentar marcar todos.");
    }
  },
};
