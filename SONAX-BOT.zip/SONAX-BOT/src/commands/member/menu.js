const { PREFIX, ASSETS_DIR } = require("../../config");
const { menuMessage } = require("../../utils/messages");
const path = require("path");

module.exports = {
  name: "menu",
  description: "Menu de comandos",
  commands: ["menu", "help"],
  usage: `${PREFIX}menu`,
  handle: async ({ sendReact, sendImageFromFile }) => {
await sendReact("💙")
await sendImageFromFile(
      path.join(ASSETS_DIR, "images", "menu-bot.png"),
      `\n\n${menuMessage()}`
    );
  },
};
